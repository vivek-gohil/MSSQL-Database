import random

print(random.randint(1,100))
#Write a program that generates a random number and 
# asks the user to guess what the number is. 
# If the user's guess is higher than the random number, 
# the program should display "Too high, try again." 
# If the user's guess is lower than the random number, 
# the program should display "Too low, try again." 
# The program should use a loop that repeats until 
# the user correctly guesses the random number. 
# Program should count and display number of tries to win the game.
num = random.randint(1,100)
att_count = 0;
user_input = int(input("Enter you guess number"))
while num != user_input:
    att_count += 1    
    if user_input < num:
        print("Too low")
        user_input = int(input("Enter you guess number"))
    elif user_input > num:
        print("Too high")
        user_input = int(input("Enter you guess number"))
    else:
        break
print("You have guessed it correct!!")
print("Total Attempts :: " , att_count)