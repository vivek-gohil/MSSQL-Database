#Simple Print 
print('Hello World')
print(1+2)
print(7*6)
print()
print("The end")

#Let try by passing mulitple args to print function
print("Step 1","Python is simple","Keep watching to learn more amout python","3.11")
