#if else block
name = input("enter your name")
age = int(input("enter your age"))
print(name)
print(age)

print(type(name))
print(type(age))

#if age is greater than 18 then print you are old enough to vote else print 
# try next year
if age >= 18:
    print("You are old enough to vote")
else:
    print("please try next year")