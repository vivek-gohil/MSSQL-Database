def add(x,y):
    """Add Function"""
    return x+y

def subtract(x,y):
    """Subtract Function"""
    return x-y

def multiply(x,y):
    """Multiply Function"""
    return x*y

def divide(x,y):
    """Divide Function"""
    if y == 0:
        raise ValueError("Cannot divide by zero!")
    return x/y

# accept two numbers from user and ask choice add , subtract , multiply ,divide
# based on choice do the calculation and print result

# num1 = int(input("Enter First Number"))
# num2 = int(input("Enter Second Number"))

# print("1. Add")
# print("2. Subtract")
# print("3. Multiply")
# print("4. Divide")

# print("Enter your choice")
# choice = int(input())

# #Python version 3.10 onwards
# match choice:
#     case 1:
#         result = add(num1,num2)
#         print("Result :: ", result)
#     case 2:
#         result = subtract(num1,num2)
#         print("Result :: ", result)
#     case 3:
#         result = multiply(num1,num2)
#         print("Result :: ", result)
#     case 4:
#         result = divide(num1,num2)
#         print("Result :: ", result)


