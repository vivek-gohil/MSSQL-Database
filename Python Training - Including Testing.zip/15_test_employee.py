import unittest
from employee import Employee

class TestEmployee(unittest.TestCase):
    def setUp(self):
        print()
        print("setUp start")
        self.emp_1 = Employee('Vivek','Gohil',50000)
        self.emp_2 = Employee('Shreyas','Achari' ,60000)
        print("setUp end")
        print()

    def tearDown(self):
        print()
        print("tearDown start")
        print("tearDown end")
        print()

    def test_email(self):
        print()
        print("test_email start")
        self.assertEqual(self.emp_1.email , 'Vivek.Gohil@email.com')
        self.assertEqual(self.emp_2.email , 'Shreyas.Achari@email.com')
        print("test_email end")
        print()

    def test_fullname(self):
        print()
        print("test_fullname start")
        self.assertEqual(self.emp_1.fullname , 'Vivek Gohil')
        self.assertEqual(self.emp_2.fullname , 'Shreyas Achari')
        print("test_fullname end")
        print()

    def test_applyraise(self):
        print()
        print("test_applyraise start")
        self.emp_1.apply_raise()
        self.emp_2.apply_raise()
        self.assertEqual(self.emp_1.salary,52500)
        self.assertEqual(self.emp_2.salary , 63000)
        print("test_applyraise end")
        print()

if __name__ == '__main__':
    unittest.main()
#https://docs.python.org/3/library/unittest.html#unittest.TestCase.debug

