import unittest
import calculations

class TestCalculations(unittest.TestCase):
    def test_add(self):
        self.assertEquals(calculations.add(10,5) , 15)
        self.assertEquals(calculations.add(-1,1) , 0)
        self.assertEquals(calculations.add(-1,-1),-2)

    def test_subtract(self):
        self.assertEquals(calculations.subtract(10,5) ,5)
        self.assertEquals(calculations.subtract(-1,1),-2)
        self.assertEquals(calculations.subtract(-1,-1),0)

    def test_multiply(self):
        self.assertEquals(calculations.multiply(10,5) , 50)
        self.assertEquals(calculations.multiply(-1,1),-1)
        self.assertEquals(calculations.multiply(-1,-1),1)

    def test_divide(self):
        self.assertEquals(calculations.divide(10,5) , 2)
        self.assertEquals(calculations.divide(-1,1) , -1)
        self.assertEquals(calculations.divide(-1,-1),1)

        self.assertRaises(ValueError,calculations.divide , 10 ,0)

if __name__ == '__main__':
    unittest.main()