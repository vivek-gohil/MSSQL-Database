age = 24
print(age)

#lets understand what type it is
print(type(age))

age_in_words = "Two years"
print(type(age_in_words))


#print("age is "+ age)
print("Age in words "+ age_in_words)