a = 12
b = 3

print(a + b) # 14
print(a - b) # 9
print(a * b) # 36
print(a / b) # 4.0
print(a // b)# 4  
print(a % b) # 0

a = 2
b = 3

print(a ** b) # power

print()
print()
for i in range(1,4):
    print(i)