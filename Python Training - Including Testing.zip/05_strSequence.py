message = "Python is simple"
print(message)
print(message[0])
print(message[1])
print(message[2])

print(message[0:6])
print(message[:6])
print(message[0:])