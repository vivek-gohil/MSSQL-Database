myList = []
size = int(input("How many elements you want to store ?"))

print("Enter ", size , "Elements ")
for i in range(size):
    number = int(input())
    myList.append(number)

print("Elements in list")
for i in myList:
    print(i)

print("Printing alternate elements from list")
for i in range(0,size,2):
    print(myList[i])

# Accept 10 numbers and print total +tive , -tive and zeros and display the count of each
count_pos = 0
count_neg = 0
count_zer = 0
for i in myList:
    if i < 0:
        count_neg += 1
    elif i > 0:
        count_pos += 1
    else:
        count_zer += 1

print("Total +Tive :: " , count_pos)
print("Total -Tive :: " , count_neg)
print("Total Zero :: " , count_zer)    