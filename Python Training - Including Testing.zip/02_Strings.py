print("Today is the good day to learn Python")
print('Python is fun')
print('We can even include "quotes" in string ')
print("Hello" + "World")

greeting ="Hello"
name="Vivek"

print(greeting , name)
print(greeting ," ", name)

#Lets accept value from user - User Inpugt
name = input("Please enter name")
print("Hello " + name)
