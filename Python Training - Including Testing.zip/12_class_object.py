#create simple class
class MyClass:
    x = 5

print(MyClass)

print("-"*80)

#creating object of MyClass
myClass = MyClass()
print(myClass.x)


print("-"*80)
#__init__ method
class Person:
    def __init__(self):
        print("init called")

person = Person()
person_2 = Person()

print("-"*80)
#Create a class named Person , use __init__() to assign values for varirable name and age
class Person:
    def __init__(self, name , age):
        self.name = name
        self.age = age

    def details(self):
        print("Name ::" , self.name , "Age ::" , self.age)

p = Person("Vivek",33)
print(p)
print(p.name)
print(p.age)
p.details()

#Create a class Employee with 3 instance variable first_name , last_name , salary 
#Create a print_full_name method which will concat the first name and last name to print
#Create object of Employee class and call print_full_name method




