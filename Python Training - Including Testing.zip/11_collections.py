#Collections
#Pthon have four collections data types
#1. List : ordered and changeble , allows duplicates 
#2. Tuple : ordered and unchangeble , Allows duplicates
#3. Set : unordered and nuindexed , no duplicates
#4. Dictionary : unordered , changeable  and indexed , no duplicates

#simple list
employees = ["Shreyas","Venkata","Sarthakkumar","Vijay","Vijay","Sarthakkumar"]
print(employees)
print(employees[2])
employees[2] = "Mayur"
print(employees)
employees.append("Madhavi")
print(employees)
employees.remove("Mayur")
print(employees)
employees.clear()
print(employees)

#Tuples : Ordered and unchangeable
cars = ("Nano","i20","Breeza","Breeza")
print(cars)
print(cars[0])
#cars[0] = "Nexon"

#Set : Unordered and unidexed
fruits = {"Mango","Pineapple","Banana"}
print(fruits)
fruits.add("Orange")
print(fruits)
fruits.remove("Orange")

#Dictionaries : unordered , changeable and indexed , key and value
employee = {
    "employeeId": 101,
    "first_name":"Shreyas",
    "last_name":"Achari"
}

print(employee)
print(employee["first_name"])
employee["first_name"] = "Shri"
print(employee)
print(employee["first_name"])

for e in employee:
    print(employee[e])