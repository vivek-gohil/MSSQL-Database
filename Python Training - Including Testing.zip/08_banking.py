main_balance = 10000
overdraft_balance = 50000

def print_all_balances():
    print("Overdraft Balance " , overdraft_balance)
    print("Main Balance " , main_balance)

print_all_balances()
