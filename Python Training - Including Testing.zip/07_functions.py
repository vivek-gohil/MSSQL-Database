main_balance = 10000
overdraft_balance = 50000
initial_overdraft_balance = 50000
def withdraw(amount):
    if amount > 0:
        global main_balance
        global overdraft_balance
        if amount <= main_balance:
            main_balance = main_balance-amount
        if amount > main_balance and amount <= main_balance + overdraft_balance :
            amount = amount - main_balance   
            main_balance = 0
            overdraft_balance = overdraft_balance - amount

def deposit(amount):
    if amount > 0:
        global main_balance
        global overdraft_balance
        global initial_overdraft_balance
        if(initial_overdraft_balance > overdraft_balance ):
            if amount < (initial_overdraft_balance - overdraft_balance ):
                overdraft_balance = overdraft_balance + amount
            if amount > (initial_overdraft_balance - overdraft_balance):
                amount = amount - (initial_overdraft_balance - overdraft_balance)
                overdraft_balance = initial_overdraft_balance
                main_balance = main_balance + amount
            





def print_all_balances():
    print("Overdraft Balance " , overdraft_balance)
    print("Main Balance " , main_balance)

def print_var_args(*args):
    text = ""
    for temp in args:
        text += str(temp) + " "
    print(text)


#print_var_args("Hi","Hello","How are you")

#create a functions with var args
# sum(*args) : will print the sum of all numbers 
# max(*args) : will print the min of all numbers





print_all_balances()
print()
print("Calling withdraw :: 5000")
withdraw(5000)
print_all_balances()
print()
print("Calling withdraw :: 15000")
withdraw(15000)
print_all_balances()
print()
print("Calling deposit :: 5000")
deposit(5000)
print_all_balances()
print()
print("Calling deposit :: 20000")
deposit(20000)
print_all_balances()
